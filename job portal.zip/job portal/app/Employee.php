<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
   // protected $table = 'user_table';
    protected $primaryKey = 'emp_id';
    public $timestamps = false;
}
