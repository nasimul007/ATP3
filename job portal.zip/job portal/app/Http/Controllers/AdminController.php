<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\AdminRequest;

class AdminController extends Controller
{
    public function index(){
    	return view('admin.index');
    }

    public function userList(){

    	$users = DB::table('employees')->get();
    	return view('admin.userList')->with('users', $users);

    }

    public function create(){

    	return view('admin.create');
    }

    public function store(Request $request){

    	$user = new employee();

    	$user->empName = $request->name;
    	$user->comName = $request->comName;
        $user->contNo = $request->contNo;
        $user->username = $request->username;
    	$user->pass = $request->password;
    	$user->type = $request->type;


    	if ($user->save()) {
    		// $request->session()->flash('message', 'Successfully Registered. Now you can login');
    		return redirect()->route('admin.index');
    	}
    }

    public function edit($emp_id){

    	$user = Employee::find($emp_id);
    	return view('admin.edit')->with('user', $user);
    }

    public function update(AdminRequest $request){

    	$user = Employee::find($request->id);

		$user->empName = $request->name;
        $user->comName = $request->comName;
        $user->contNo = $request->contNo;
        $user->username = $request->username;
        $user->pass = $request->password;
        $user->type = $request->type;

    	$user->save();
    	return redirect()->route('admin.userList');    	
    }

    public function delete($emp_id){

    	$user = Employee::find($emp_id);
    	return view('admin.delete')->with('user', $user);
    }

    public function destroy(Request $request){
    	Employee::destroy($request->id);
    	return redirect()->route('admin.userList');
    }
}
