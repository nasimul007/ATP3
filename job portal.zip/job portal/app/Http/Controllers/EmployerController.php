<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Job;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\EmployeeRequest;

class EmployerController extends Controller
{
    public function index(){
    	return view('employer.index');
    }

    public function createJob(){
    	return view('employer.createJob');
    }

    public function storeJob(Request $request){
    	$job = new Job();

    	$job->comName = $request->comName;
    	$job->jobTitle = $request->jobTitle;
    	$job->jobLoc = $request->jobLocation;
    	$job->sal = $request->salary;

    	$job->save();

    	return redirect()->route('employer.index');
    }

    public function jobList(){
    	$jobs = DB::table('jobs')->get();
    	return view('employer.jobList')->with('jobs', $jobs);
    }

    public function jobEdit($job_id){
    	$job = Job::find($job_id);
    	return view('employer.jobEdit')->with('job', $job);
    }

    public function jobUpdate(EmployeeRequest $request){
    	$job = Job::find($request->id);

    	$job->comName = $request->comName;
    	$job->jobTitle = $request->jobTitle;
    	$job->jobLoc = $request->jobLocation;
    	$job->sal = $request->salary;

    	$job->save();

    	return redirect()->route('employer.jobList');
    }

    public function jobDelete(Request $request){
    	Job::destroy($request->id);
    	return redirect()->route('employer.jobList');
    }
}
