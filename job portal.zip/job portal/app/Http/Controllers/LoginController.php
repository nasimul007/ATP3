<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Employee;
use Illuminate\Support\Facades\DB;


class LoginController extends Controller
{
    public function index(Request $request){


        /*$users = User::all();
        var_dump($users);*/

       /* $user = User::where('username', 'admin')
                    ->where('password', 'admin')
                    ->first();*/
        /*$user = User::find(1);*/

         $user = DB::table('employees')
                    ->where('username', 'admin')
                    ->where('pass', 'admin')
                    ->first();

    	if($user == null){
    		return view('login.index');
    	}else{
    		//echo $request->name;
    		return view('login.index')->with('username', $request->username);
    	}
    	
    }

    public function verify(Request $request){
    	
    	$username = $request->username;
    	//$password = $request->input('password');

        $user = DB::table('employees')
                    ->where('username', $username)
                    ->first();

        if ($user != null) {

            $password = $user->pass;

            if ($request->password == $password) {

                if ($user->type == 'admin') {
                    //echo "logged as admin";
                    return redirect()->route('admin.index');
                }
                else{
                    echo "logged as user";
                    return redirect()->route('employer.index');
                }
            }
            else{
                $request->session()->flash('message', 'Invalid password');
                return redirect()->route('login.index', ['username'=>$username]);
            }
        }
        else{
			
			$request->session()->flash('message', 'Invalid username');

			//$request->session()->flash('uname', $uname);

			return redirect()->route('login.index', ['username'=>$username]);
		}
    	
    }
}
