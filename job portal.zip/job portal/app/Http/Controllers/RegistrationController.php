<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use App\Http\Requests\RegistrationRequest;

class RegistrationController extends Controller
{
    public function index(){
    	return view('registration.index');
    }

    public function store(Request $request){

    	$user = new Employee();

    	$user->empName = $request->name;
        $user->comName = $request->comName;
        $user->contNo = $request->contNo;
        $user->username = $request->username;
        $user->pass = $request->password;
        $user->type = $request->type;


    	if ($user->save()) {
    		$request->session()->flash('message', 'Successfully Registered. Now you can login');
    		return redirect()->route('login.index');
    	}

    }
}
