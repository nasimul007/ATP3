<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;

class SearchController extends Controller

{

   public function index(){

		return view('search.search');
	}

	public function search(Request $request){

		if($request->ajax()){

			$output="";

			$users=DB::table('employees')->where('empName','LIKE','%'.$request->search."%")->get();

			if($users){

				foreach ($users as $key => $u) {
					$output.='<tr>'.

					'<td>'.$u->empName.'</td>'.
					'<td>'.$u->comName.'</td>'.
					'<td>'.$u->contNo.'</td>'.
					'</tr>';
				}
				return Response($output);
			}
		}
	}
}