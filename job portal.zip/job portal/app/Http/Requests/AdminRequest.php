<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;


class AdminRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'=>'required',
            'comName'=>'required',
            'contNo'=>'required',
            'type'=>'required',
            'username'=>'required',
            'password'=>'required'
        ];
    }

    public function messages(){
        return [
            'name.required'=>'Name can not be empty',
            'password.required'=>'Password can not be empty',
            'comName.required'=>'Company Name can not be empty',
            'contNo.required'=>'Contact Number can not be empty',
            'type.required'=>'Type can not be empty'
        ];
    }
}
