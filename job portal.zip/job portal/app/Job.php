<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
   // protected $table = 'user_table';
    protected $primaryKey = 'job_id';
    public $timestamps = false;
}
