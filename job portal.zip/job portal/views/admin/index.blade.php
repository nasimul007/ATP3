<!DOCTYPE html>
<html>
<head>
	<title>admin home</title>
</head>
<body>
	<h1>Admin Home</h1>

	<a href="{{route('admin.create')}}"> Register new employee </a> | 
	<a href="{{route('admin.userList')}}"> List Of employees </a> | 
	<a href="{{route('logout.index')}}"> Logout</a> 
</body>
</html>