<!DOCTYPE html>
<html>
<head>
	<title>employee list</title>
	<style>
	table, th, td {
	    border: 1px solid black;
	}
	</style>
</head>
<body>
	<h1>Employee List</h1>

	<a href="{{route('admin.index')}}">Back</a> | 
	<a href="{{route('logout.index')}}"> Logout</a> |
	<a href="{{route('search.index')}}"> Search User</a>

	<table>
		<tr>
			<th>ID</th>
			<th>Employee Name</th>
			<th>Company Name</th>
			<th>Contact Number</th>
			<th>User Type</th>
			<th>Others</th>
		</tr>
		@foreach($users as $u)
		<tr>
			<td>{{$u->emp_id}}</td>
			<td>{{$u->empName}}</td>
			<td>{{$u->comName}}</td>
			<td>{{$u->contNo}}</td>
			<td>{{$u->type}}</td>
			<td><a href="{{route('admin.edit', [$u->emp_id])}}">Edit</a> |
			<a href="{{route('admin.delete', [$u->emp_id])}}">Delete</a></td>
		</tr>
		@endforeach

	</table>

</body>
</html>