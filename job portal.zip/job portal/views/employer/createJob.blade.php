<!DOCTYPE html>
<html>
<head>
	<title>add job</title>
</head>
<body>
	<h1>Add a New Job</h1>
	<a href="{{route('employer.index')}}">Back</a>

	<form method="post">
		
		<input type="hidden" name="_token" value="{{ csrf_token() }}">
		<table>
			<tr>
				<td>Company Name :</td>
				<td><input type="text" name="comName" value="{{old('comName')}}"></td>
			</tr>
			<tr>
				<td>Job Title  :</td>
				<td><input type="text" name="jobTitle" value="{{old('jobTitle')}}"></td>
			</tr>
			<tr>
				<td>Job Location :</td>
				<td><input type="text" name="jobLocation" value="{{old('jobLocation')}}"></td>
			</tr>
			<tr>
				<td>Salary :</td>
				<td><input type="text" name="salary" value="{{old('salary')}}"></td>
			</tr>
			<tr>
				<td>
					<input type="submit" name="submit" value="Submit">
					<input type="reset" name="reset" value="Reset">
				</td>
			</tr>
		</table>

</body>
</html>