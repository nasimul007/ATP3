<!DOCTYPE html>
<html>
<head>
	<title>employer home</title>
</head>
<body>
	<h1>Employer Home</h1>

	<a href="{{route('employer.createJob')}}"> Add New JOB </a> | 
	<a href="{{route('employer.jobList')}}"> List Of jobs </a> | 
	<a href="{{route('logout.index')}}"> Logout</a> 
</body>
</html>