<!DOCTYPE html>
<html>
<head>
	<title>job list</title>
	<style>
	table, th, td {
	    border: 1px solid black;
	}
	</style>
</head>
<body>
	<h1>All Job</h1>

	<a href="{{route('employer.index')}}">Back</a> | 
	<a href="{{route('logout.index')}}"> Logout</a> |
	<!-- <a href="{{route('search.index')}}"> Search User</a> -->

	<table>
		<tr>
			<th>ID</th>
			<th>Company Name</th>
			<th>Job Title</th>
			<th>Job Location</th>
			<th>Salary</th>
			<th>Others</th>
		</tr>
		@foreach($jobs as $j)
		<tr>
			<td>{{$j->job_id}}</td>
			<td>{{$j->comName}}</td>
			<td>{{$j->jobTitle}}</td>
			<td>{{$j->jobLoc}}</td>
			<td>{{$j->sal}}</td>
			<td><a href="{{route('employer.jobEdit', [$j->job_id])}}">Edit</a> |
			<a href="{{route('employer.jobDelete', [$j->job_id])}}">Delete</a></td>
		</tr>
		@endforeach

	</table>

</body>
</html>