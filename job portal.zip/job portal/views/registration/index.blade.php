<!DOCTYPE html>
<html>
<head>
	<title>create user</title>
</head>
<body>
	<h1>Registration Page</h1>

	<a href="{{route('welcome.index')}}">Back</a>

	<form method="post">
		
		<input type="hidden" name="_token" value="{{ csrf_token() }}">
		<table>
			<tr>
				<td>Your Name :</td>
				<td><input type="text" name="name" value="{{old('name')}}"></td>
			</tr>
			<tr>
				<td>Company Name :</td>
				<td><input type="text" name="comName" value="{{old('comName')}}"></td>
			</tr>
			<tr>
				<td>Phone Number :</td>
				<td><input type="text" name="contNo" value="{{old('contNo')}}"></td>
			</tr>
			<tr>
				<!-- <td>Type :</td> -->
				<td><input type="hidden" name="type" value="user"></td>
			</tr>
			<tr>
				<td>User Name :</td>
				<td><input type="text" name="username" value="{{old('username')}}"></td>
			</tr>
			<tr>
				<td>Password :</td>
				<td><input type="password" name="password" value="{{old('password')}}"></td>
			</tr>
			<tr>
				<td>
					<input type="submit" name="submit" value="Submit">
					<input type="reset" name="reset" value="Reset">
				</td>
			</tr>
		</table>
	</form>
		<div style="color: red">
			@if($errors->any())
				@foreach($errors->all() as $err)
				{{$err}} <br>
				@endforeach
			@endif
		</div>
</body>
</html>