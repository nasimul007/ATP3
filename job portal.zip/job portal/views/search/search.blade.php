<!DOCTYPE html>

<html>
<head>
	<meta name="_token" content="{{ csrf_token() }}">
	<title>Search employee</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<style>
		table, th, td {
		    border: 1px solid black;
		}
	</style>
</head>

<body>
	<a href="{{route('admin.userList')}}">Back</a> | 
	<a href="{{route('logout.index')}}"> Logout</a>

	<h3>Employee info </h3>
		<input type="text" id="search" name="search" placeholder="type here to search"></input>
		<table>
			<thead>
				<tr>
					<th>Employee Name</th>
					<th>Company Name</th>
					<th>Contact Number</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>

	<script type="text/javascript">
		$('#search').on('keyup',function(){
			$value=$(this).val();
			$.ajax({
				type : 'get',
				url : '{{URL::to('searchValue')}}',
				data:{'search':$value},
				success:function(data){
					$('tbody').html(data);
				}
			});
		})
	</script>

	<script type="text/javascript">
		$.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
	</script>
</body>
</html>