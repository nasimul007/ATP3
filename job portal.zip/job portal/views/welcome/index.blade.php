<!DOCTYPE html>
<html>
<head>
	<title>welcome page</title>
</head>
<body>

	<h1>Welcome to job Portal</h1>
	<a href="{{route('login.index')}}"> Login</a> |
	<a href="{{route('registration.index')}}"> Registration</a> 

</body>
</html>