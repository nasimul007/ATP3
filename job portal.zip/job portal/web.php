<?php


Route::get('/', 'WelcomeController@index')->name('welcome.index');

Route::get('/login', 'LoginController@index')->name('login.index');
Route::post('/login', 'LoginController@verify')->name('login.verify');

Route::get('/logout', 'LogoutController@index')->name('logout.index');

Route::get('/registration', 'RegistrationController@index')->name('registration.index');
Route::post('/registration', 'RegistrationController@store');

Route::get('/adminHome', 'AdminController@index')->name('admin.index');
Route::get('/adminHome/userList', 'AdminController@userList')->name('admin.userList');

Route::get('/adminHome/create', 'AdminController@create')->name('admin.create');
Route::post('/adminHome/create', 'AdminController@store');

Route::get('/adminHome/userList/edit/{id}', 'AdminController@edit')->name('admin.edit');
Route::post('/adminHome/userList/edit/{id}', 'AdminController@update');

Route::get('/adminHome/userList/delete/{id}', 'AdminController@delete')->name('admin.delete');
Route::post('/adminHome/userList/delete/{id}', 'AdminController@destroy');

Route::get('/search','SearchController@index')->name('search.index');
Route::get('/searchValue','SearchController@search');

Route::get('/employerHome', 'EmployerController@index')->name('employer.index');

Route::get('/employerHome/createJob', 'EmployerController@createJob')->name('employer.createJob');
Route::post('/employerHome/createJob', 'EmployerController@storeJob');

Route::get('/employerHome/jobList', 'EmployerController@jobList')->name('employer.jobList');

Route::get('/employerHome/jobList/jobEdit/{id}', 'EmployerController@jobEdit')->name('employer.jobEdit');
Route::post('/employerHome/jobList/jobEdit/{id}', 'EmployerController@jobUpdate');

Route::get('/employerHome/jobList/jobDelete/{id}', 'EmployerController@jobDelete')->name('employer.jobDelete');